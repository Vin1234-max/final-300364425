function start() {
    // Set the countdown date to August 25, 2024
    var countDownDate = new Date("2024-08-25T00:00:00").getTime();

    // Debugging: Check the countdown date
    console.log("Countdown Date:", new Date(countDownDate));

    // Update the countdown every 1 second
    var intervalId = setInterval(function() {
        var now = new Date().getTime();
        var distance = countDownDate - now;

        // Debugging: Check the distance
        console.log("Distance:", distance);

        if (distance < 0) {
            clearInterval(intervalId);
            document.getElementById("demo").innerHTML = "EXPIRED";
            return;
        }

        var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);

        document.getElementById("demo").innerHTML = 
            days + " <sub>days</sub> " + 
            hours + " <sub>hrs</sub> " + 
            minutes + " <sub>mins</sub> " + 
            seconds + " <sub>scnds</sub>";
    }, 1000); // Update every 1 second
}


